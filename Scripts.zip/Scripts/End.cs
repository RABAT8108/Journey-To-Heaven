﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class End : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D Trig)
    {
        if (Trig.gameObject.tag == "Finish")
        {
            new WaitForSeconds(0.5f);
            Destroy(Trig.gameObject);
            

            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}

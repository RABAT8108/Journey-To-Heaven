﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMov : MonoBehaviour
{
    private Rigidbody2D rb;
    public float movspeed=2;
    private Transform tform;
    private SpriteRenderer sp;
    // Start is called before the first frame update
    void Start()
    {
        sp = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        tform = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(movspeed, 0);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "enemyrange")
        { 
            Debug.Log("Collided");
            sp.flipX = true;
            movspeed = -1 * movspeed;
            Debug.Log("movspeed =" + movspeed);

        }
    }

  
 
    }



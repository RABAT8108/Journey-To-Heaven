﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{   
    //Move related variables
    public float moveSpeed = 5f;
    private float horizontal;

    //Animation related variables
    private Animator anim;
    private Rigidbody2D rb;

    // Jump related variables
    public float jForce;
    private bool isGrounded;
    public Transform groundCheck;
    public LayerMask ground;
    public float checkradius;
    private int extrajump;

    void Start()
    {  
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        isGrounded = true;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkradius, ground);
        
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0f, 0f);
        transform.position += movement * Time.deltaTime * moveSpeed;
        if (Input.GetAxis("Horizontal") != 0)
        {
            anim.SetFloat("horizontal", Mathf.Abs(Input.GetAxis("Horizontal")));
        }
        Flip();

    }

    private void Update()
    {
        if (isGrounded == true)
        {
            extrajump = 1;
        }
        if (Input.GetButtonDown("Jump") && extrajump > 0)
        {
            rb.AddForce(new Vector2(transform.position.x * Time.deltaTime, jForce), ForceMode2D.Impulse);
            extrajump--;
        }
        else if (Input.GetButtonDown("Jump") && extrajump == 0 && isGrounded == true)
        {
            rb.AddForce(new Vector2(transform.position.x * Time.deltaTime, jForce), ForceMode2D.Impulse);
        }
    }

    void Flip()
    {
        if (Input.GetAxis("Horizontal") > 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }
        if (Input.GetAxis("Horizontal") < 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = false;
        }
    }
}

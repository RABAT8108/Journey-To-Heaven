﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class StartDialogue : MonoBehaviour
{
    private Queue<string> sentences;
    public Text name;
    public Text dialogueText;

    // Start is called before the first frame update
    void Start()
    {
        sentences = new Queue<string>();

    }

    public void Startdialogue(Dialogue dialogue)
    {
        Debug.Log("starting conversation with" + dialogue.name);

        name.text = dialogue.name;
        

        foreach (string sentence in dialogue.sentences)
        {
            sentences.Enqueue(sentence);
        }
        DisplayNextSentence();
    }
    
    public void DisplayNextSentence ()
    {
        if (sentences.Count == 0)
            {
            EndDialogue();
            return;
        }
        string sentence = sentences.Dequeue();
        dialogueText.text = sentence ;
    }

    void EndDialogue()
    {
        FindObjectOfType<StartMov>().BacktoMov();
        FindObjectOfType<WiseDemonTrigg>().whenDone();

    }
}


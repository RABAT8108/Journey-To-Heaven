﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartMov : MonoBehaviour
{
    private Rigidbody2D rb;
    public float movspeed;
    private bool isMove = true;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    private void Update()
    {
        if (isMove == true)
        { rb.velocity = new Vector2(movspeed, rb.velocity.y); }
    }
    public void stopMov()
    {
        rb.velocity = new Vector2(0, 0);
        isMove = false;
    }
    public void BacktoMov()
    {
        isMove = true;
    }
}

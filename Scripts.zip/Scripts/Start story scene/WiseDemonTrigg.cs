﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WiseDemonTrigg : MonoBehaviour
{
    // Start is called before the first frame update
    public Dialogue dialogue;
    public GameObject cvas;
    public GameObject player;
  

  
    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            //Time.timeScale = 0;
            cvas.gameObject.SetActive(true);
            FindObjectOfType<StartDialogue>().Startdialogue(dialogue);
            Debug.Log("Entered");
            FindObjectOfType<StartMov>().stopMov();

        }
    }
    public void whenDone()
    {
        cvas.gameObject.SetActive(false);
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamMov : MonoBehaviour
{
    public Transform target;
    public float smoothTime = 0.3F;
    private Vector3 velocity = Vector3.zero;
    public float minX, maxX, minY, maxY;
    

    void Update()
    {
        // Define a target position above and behind the target transform
        Vector3 targetPosition = target.TransformPoint(new Vector3(0, 0.3f, -10));

        // Smoothly move the camera towards that target position
        Vector3 smoothPos = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);

        //Clamps the camera between the stages
        transform.position = new Vector3(Mathf.Clamp(smoothPos.x, minX, maxX), Mathf.Clamp(smoothPos.y, minY, maxY), smoothPos.z);

    }
}

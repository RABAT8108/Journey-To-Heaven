﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NewGame : MonoBehaviour
{
    public GameObject gb;
    // Start is called before the first frame update
    public void Newgame()
    {
        SceneManager.LoadScene(1);
    }
    public void tutorial()
    {
        gb.SetActive(true);
    }
    public void tutorialContinue()
    {
        gb.SetActive(false);
    }
}

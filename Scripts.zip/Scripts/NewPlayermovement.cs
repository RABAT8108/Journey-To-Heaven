﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class NewPlayermovement : MonoBehaviour
{
    //Move related variables
    public float moveSpeed = 5f;
    private float horizontal;
    public GameObject gb;
    public Transform PLEASE;

    //Animation related variables
    private Animator anim;
    private Rigidbody2D rb;

    // Jump related variables
    public float jForce;
    private bool isGrounded;
    public Transform groundCheck;
    public LayerMask ground;
    public float checkradius;
    public float timer = 5;
    public Text countdownTimerText;
    public int powerjumpvalue;
    private float setTimerValue = 5.4f;
    public GameObject hatTimer;
    public GameObject hatTimerText;
    private float healthValue;
    public Slider sl;
    public GameObject boss;

    [SerializeField] private AudioSource jumpAudio;
    [SerializeField] private AudioSource tonic;
    [SerializeField] private AudioSource deatheffect;
    void Start()
    {
        healthValue = 10;
        PLEASE = this.transform;
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        isGrounded = true;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkradius, ground);

        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0f, 0f);
        transform.position += movement * Time.deltaTime * moveSpeed;
        if (Input.GetAxis("Horizontal") != 0)
        {
            anim.SetFloat("horizontal", Mathf.Abs(Input.GetAxis("Horizontal")));
        }
        Flip();
        if (timer > 0 && isGrounded == true)
        {
            timer = timer - 1 * Time.deltaTime;
        }
        else if (timer <= 0)
        { timer = setTimerValue; }

    
      
    }

    private void Update()
    {
        
        if (timer <= 0 && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jForce);

            jumpAudio.Play();


        }
        countdownTimer();

        sl.value = healthValue;
        DestroyBoss();
    }

    void Flip()
    {
        if (Input.GetAxis("Horizontal") > 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }
        if (Input.GetAxis("Horizontal") < 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = false;
        }
    }
    private void countdownTimer()
    {
        countdownTimerText.text = timer.ToString("0");
    }
  public void changetimer()
    {
        setTimerValue = 3;
        Debug.Log("changed");
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Timehat")
        {
            gb.SetActive(true);
            setTimerValue = 3;
            hatTimer.SetActive(true);
            hatTimerText.SetActive(true);
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "Tonic")
        {
            FindObjectOfType<InstantiatePlatform>().StartCoroutine("instPlatform");
            Destroy(collision.gameObject);
            healthValue -= 1;
            tonic.Play();
        }
       
        
    }

    private void DestroyBoss()
    {
        if (healthValue <=0)
        {
            
            Destroy(boss);
            SceneManager.LoadScene("Game End");
            deatheffect.Play();
        }
    }
    
}


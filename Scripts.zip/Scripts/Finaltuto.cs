﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finaltuto : MonoBehaviour
{
    public void Continue()
    {

        SceneManager.LoadScene("Final");
    }
}

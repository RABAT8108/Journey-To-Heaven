﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiatePlatform : MonoBehaviour
{
    public GameObject CloudPlatform;
    public float minX, maxX;

    private void Start()
    {
        FindObjectOfType<StartMov>().BacktoMov();
    }
    public IEnumerator instPlatform()
    {

        yield return new WaitForSeconds(2f);
        Instantiate(CloudPlatform, new Vector3(Random.Range (minX, maxX), transform.position.y, transform.position.z), Quaternion.identity);
        
    }
    
}

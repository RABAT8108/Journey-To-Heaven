﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Death : MonoBehaviour
{
    private float varTime = 0.5f;
    public GameObject gb;

    // Start is called before the first frame update
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Death")
        {
            
            Destroy(this.gameObject, varTime);
            gb.SetActive(true);
        }
    }

}

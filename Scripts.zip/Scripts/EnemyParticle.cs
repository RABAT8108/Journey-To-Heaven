﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyParticle : MonoBehaviour
{
    private Transform player;
    private Vector2 target;
    public float speed;
   // public GameObject Player;
    void Start()
    {
        player = FindObjectOfType<NewPlayermovement>().PLEASE;

        target = new Vector2(player.transform.position.x, player.transform.position.y);
   
    }


    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, target, speed * Time.deltaTime);
        if (this.transform.position.x == target.x && this.transform.position.y == target.y)
        {
            destroyProjectile();
        }
    }
    
    void destroyProjectile()
    {
        Destroy(this.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            destroyProjectile();
        }
    }
}
